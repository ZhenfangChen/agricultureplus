mapboxgl.accessToken = 'pk.eyJ1IjoiemhlbmZhbmciLCJhIjoiY2pjdjR0NXZqMG8ycTJxb2Z3czB6Z2dtcSJ9.-rPyXSJ6XQ_bp7W4ytuqkw';

var map = new mapboxgl.Map({
	container: 'map',
	minZoom: 10,
	maxZoom: 17,
	style: 'mapbox://styles/zhenfang/ck24u74by0ni61cqvrrs213zy'
	

});
